<?php $__env->startSection('title'); ?>
    الاطباء
<?php $__env->stopSection(); ?>
<?php $__env->startSection('componemt'); ?>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center mb-5 pb-5">
                <div class="col-md-7 text-center heading-section ftco-animate">
                    <h2 class="mb-3">Meet Our Experience Dentist</h2>
                    <p>A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences</p>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate">
                            <div class="staff">
                                <div class="img mb-4" style="background-image: url(<?php echo e(asset('img/'.$user->photo)); ?>);"></div>
                                
                                <div class="info text-center">
                                    <h3><a><?php echo e($user->name); ?></a></h3>
                                    <span class="position">Dentist</span>
                                    <div class="text">
                                        <p>The distinguished doctor <span><?php echo e($user->name); ?></span> is sufficiently experienced, highly skilled and has a good heart</p>
                                        <p>A student from Aleppo Free University, Faculty of Dentistry</p>
                                        <ul class="ftco-social">
                                            
                                            <li class="ftco-animate"><a class="btn btn-primary stretched-link" href="<?php echo e(route('users.edit',$user->id)); ?>">edit</a></li>
                                            <li class="ftco-animate">
                                                <a>
                                                    <form  action="<?php echo e(route('users.destroy',$user->id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <input class="btn btn-primary stretched-link" type="submit" value="delete">
                                                    </form>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>





























                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dental_Clincs\resources\views/users.blade.php ENDPATH**/ ?>