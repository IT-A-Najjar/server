<?php $__env->startSection('title'); ?>
    عرض المرضى
<?php $__env->stopSection(); ?>
<?php $__env->startSection('componemt'); ?>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center mb-5 pb-5">
                <div class="col-md-7 text-center heading-section ftco-animate">
                    <h2 class="mb-3">قائمة بجميع المرضى</h2>
                    <p>يمكنك الاطلاع على المرضى الخاصين بك ويمكنك التعديل عليهم او ارسالهم لطبيب اخر وفي حال العمل مريض ما يمكنك وضع شرح مفصل لحالة المريض</p>
                </div>
            </div>
        </div>
    </section>

    <form method="HEAD" action="<?php echo e(route('sick.index')); ?>" >
        <?php echo csrf_field(); ?>
        <div class="mt-4">
            <h4 style="text-align: center">اختر المرض </h4>
            <select name="filter" class="form-select " aria-label="Default select example">
                <option selected value=0 >عرض الكل</option>
                <?php $__currentLoopData = $illnesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($disease->id); ?>">
                        <?php echo e($disease->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php if(auth()->user()->is_admin): ?>
        <div class="mt-4">
            <h4 style="text-align: center">اختر الطبيب </h4>
            <select name="filter_doctor" class="form-select" aria-label="Default select example">
                <option selected value=0 >عرض الكل</option>
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($doctor->id); ?>">
                        <?php echo e($doctor->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    <?php endif; ?>
        <div class="flex items-center justify-end mt-4">
            <input class="btn btn-primary" type="submit" value="submit" >
        </div>

    </form>
<table class="table table-striped text-center">
    <thead>
    <tr>
        <th scope="col">id</th>
        <th scope="col">fall name</th>
        <th scope="col">age</th>
        <th scope="col">illness</th>
        <th scope="col">doctor</th>
        <th scope="col">phone</th>
        <th scope="col">control</th>
    </tr>
    </thead>
    <tbody>

<?php for($i=count($sicks)-1;$i>=0;$i--): ?>
        <?php if(!count($sicks[$i]->preview)): ?>
            <tr>
                <th scope="row"><?php echo e($sicks[$i]->id); ?></th>
                <td ><h5><?php echo e($sicks[$i]->full_name); ?></h5></td>
                <td><?php echo e($sicks[$i]->age); ?></td>
                <td><?php echo e($sicks[$i]->illness->name); ?></td>
                <td><?php echo e($sicks[$i]->user->name); ?></td>
                <td><?php echo e($sicks[$i]->phone_number); ?></td>
                <td>
                    <a class="btn btn-primary stretched-link" href="<?php echo e(url('preview.edit',$sicks[$i]->id)); ?>">Add</a>
                    <a class="btn btn-primary stretched-link" href="<?php echo e(route('sick.show',$sicks[$i]->id)); ?>">show</a>
                    <a class="btn btn-primary stretched-link" href="<?php echo e(route('sick.edit',$sicks[$i]->id)); ?>">edit</a>
                    <a class=" btn btn-primary stretched-link">
                        <form action="<?php echo e(route('sick.destroy',$sicks[$i]->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input style="background-color: #2f89fc ;color: white; border: none" class=" " type="submit" value="delete">
                        </form>
                    </a>
                </td>
            </tr>
        <?php endif; ?>
<?php endfor; ?>

    </tbody>
</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dental_Clincs\resources\views/sick/index.blade.php ENDPATH**/ ?>