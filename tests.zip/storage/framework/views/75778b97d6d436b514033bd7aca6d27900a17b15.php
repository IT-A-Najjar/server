<?php $__env->startSection('title'); ?>
    الامراض
<?php $__env->stopSection(); ?>
<?php $__env->startSection('componemt'); ?>
<section class="ftco-section">
    <div class="container">

        <div class="row">
            <?php $__currentLoopData = $illness; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate">
                    <div class="staff">
                        <div class="img mb-4" style="background-image: url(images/illness.png);"></div>
                        <div class="info text-center">
                            <h3><?php echo e($a->name); ?></h3>
                            <div class="text">
                                <p>التعديل على المرض</p>
                                <ul class="ftco-social">
                                    <li class="ftco-animate"><a class="btn btn-primary stretched-link" href="<?php echo e(route('illnesses.edit',$a->id)); ?>">edit</a></li>
                                    <li class="ftco-animate">
                                        <form action="<?php echo e(route('illnesses.destroy',$a->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input class="btn btn-primary stretched-link" type="submit" value="delete">
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dental_Clincs\resources\views/Illnesses/index.blade.php ENDPATH**/ ?>